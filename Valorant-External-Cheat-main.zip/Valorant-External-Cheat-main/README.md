open kaim3.rar for the most updated version. 
original source code is here if you want to paste your own version of the cheat.

## Game Settings
- **You have to play the game in `purple colorblind mode`**

## Ban Risk
- Currently tested and is undetected as of 4/20
## Keybinds
- trigger toggle `ctrl + alt`
- bunnyhop toggle `ctrl + space`
- `ctrl + tab` to switch mode
- `ctrl + down` to decrease `ctrl + up` to increase the trigger area

## Images from the program
![image](https://user-images.githubusercontent.com/80160410/115341717-b62fea00-a16e-11eb-9970-25e0fd296436.png)
